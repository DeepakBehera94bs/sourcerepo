# This program prints an important message!

print('Be sure to visit Patricia-Anong.com/blog!')